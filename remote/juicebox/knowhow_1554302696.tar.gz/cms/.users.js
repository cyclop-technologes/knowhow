({
	users: [
		{
			username: 'knowhow-admin',
			tags: [],
			salt: '9f0f03d94cfba5d14b24d9634382cf46',
			hash: '119eb9b0ef83f54a8442b3186e20f4f8e5bed004ded183f258e95349ad740d07',
			user_created_timestamp: 1552334599147
		}
	]
})