{
	settings: {
		$admin_background_image_type: 'image',
		admin_background_image: '/admin/assets/img/pattern.png',
		dark: true,
		login_message: '',
	}
}
